Changes in version 4.0.2
========================




:program:`Universal Feed Parser` 4.0.2 was released on December 24, 2005.

- cleared ``_debug`` flag.